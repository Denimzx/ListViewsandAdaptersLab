package co.edu.unipiloto.transporteapp;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

        public void abrirFormulario (View view){
            Intent intent = new Intent(this, FormularioPubliCarga.class);
            startActivity(intent);
        }

        public void revisarPublicaciones (View view){
            Intent intent = new Intent(this, RevisarPublicacionesActivity.class);
            startActivity(intent);
        }
        public void abrirBuscarSolicitud (View view){
            Intent intent = new Intent(this, BuscarSolicitudActivity.class);
            startActivity(intent);
        }
    public void enviarUbicacion (View view){
        Intent intent = new Intent(this, EnviarUbicacion.class);
        startActivity(intent);
    }
        public void aceptarSolicitud (View view){
            abrirBuscarSolicitud(view);
        }

}

